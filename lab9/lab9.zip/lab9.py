import surface
import rectangle

def main():
	surfaceobj = surface.Surface(filename, 5, 5, 5, 5)
	rectobj = surfaceobj.getRect()
	print(rectobj)
main()
